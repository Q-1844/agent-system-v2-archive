#!/usr/bin/env python3
"""Offline audit of the attached handoff; does not import or run the application.

Usage: python verify_attached_evidence.py /path/to/GPT交接_20261020 [output.json]
Only the three attached stdlib storage helpers are AST-extracted. Controlled
thread interleaving establishes a storage-layer limit, not production frequency.
"""
from __future__ import annotations

import ast
import copy
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path
import sys
import tempfile
import threading
from unittest.mock import patch


def audit(root: Path) -> dict:
    source = root / "取消修复复核" / "collab_modes.py"
    raw = source.read_bytes()
    parsed = ast.parse(raw.decode("utf-8"))
    functions = {"_runs_dir", "_run_path", "save_run"}
    selected = []
    for node in parsed.body:
        if isinstance(node, ast.FunctionDef) and node.name in functions:
            selected.append(node)
        elif isinstance(node, ast.Assign) and any(
            isinstance(t, ast.Name) and t.id == "_RUN_HELD_STATUSES"
            for t in node.targets
        ):
            selected.append(node)
    assert len(selected) == 4, "Unexpected attachment structure"
    namespace = {"Path": Path, "json": json}
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(source), "exec"), namespace)
    save = namespace["save_run"]
    run_path = namespace["_run_path"]
    cases = []

    with tempfile.TemporaryDirectory(prefix="collab-save-audit-") as temporary:
        project = Path(temporary)

        def seed(payload: dict) -> Path:
            p = run_path(project, payload["run_id"])
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(json.dumps(payload), encoding="utf-8")
            return p

        running = {"run_id": "run_probe", "status": "running", "result": {}}
        cancelled = {
            "run_id": "run_probe", "status": "cancelled",
            "finished_at": 100, "result": {"cancel_reason": "user stopped"},
        }

        path = seed(cancelled)
        save(project, copy.deepcopy(running))
        observed = json.loads(path.read_text(encoding="utf-8"))
        ok = observed["status"] == "cancelled" and observed["result"] == cancelled["result"]
        assert ok
        cases.append({"id": "ordinary_stale_snapshot", "category": "positive_control",
                      "guard_preserved_terminal_and_reason": ok, "observed": observed})

        seed(cancelled)
        stale_same_status = copy.deepcopy(cancelled)
        stale_same_status["result"] = {}
        stale_same_status["finished_at"] = None
        save(project, stale_same_status)
        observed = json.loads(path.read_text(encoding="utf-8"))
        issue = "cancel_reason" not in observed["result"] and observed["finished_at"] is None
        assert issue
        cases.append({"id": "same_terminal_metadata_loss", "category": "reproduced_limit",
                      "terminal_reason_and_timestamp_lost": issue, "observed": observed})

        path.write_text('{"status": "cancelled", broken', encoding="utf-8")
        save(project, copy.deepcopy(running))
        observed = json.loads(path.read_text(encoding="utf-8"))
        issue = observed["status"] == "running"
        assert issue
        cases.append({"id": "unreadable_existing_state", "category": "reproduced_limit",
                      "unreadable_state_overwritten_without_error": issue, "observed": observed})

        seed(running)
        read_complete = threading.Event()
        continue_write = threading.Event()
        original_read = Path.read_text
        errors = []

        def controlled_read(p, *args, **kwargs):
            value = original_read(p, *args, **kwargs)
            if threading.current_thread().name == "stale-writer" and p == path:
                read_complete.set()
                if not continue_write.wait(timeout=5):
                    raise RuntimeError("audit interleaving timed out")
            return value

        def stale_writer():
            try:
                save(project, copy.deepcopy(running))
            except BaseException as exc:
                errors.append(repr(exc))

        with patch.object(Path, "read_text", controlled_read):
            worker = threading.Thread(target=stale_writer, name="stale-writer")
            worker.start()
            try:
                assert read_complete.wait(timeout=5)
                save(project, copy.deepcopy(cancelled))
                before_release = json.loads(original_read(path, encoding="utf-8"))
                assert before_release["status"] == "cancelled"
            finally:
                continue_write.set()
                worker.join(timeout=5)
            assert not worker.is_alive() and not errors, errors
        observed = json.loads(path.read_text(encoding="utf-8"))
        issue = observed["status"] == "running"
        assert issue
        cases.append({"id": "interleaved_read_check_write", "category": "reproduced_limit",
                      "cancelled_state_replaced_with_running": issue,
                      "scope": "controlled concurrent writers; not a frequency estimate or proof of current event-loop interleaving",
                      "before_stale_write": before_release, "observed": observed})

    evidence = root / "证据"
    feedback = {}
    for filename in ["FEEDBACK_E_R11.json", "FEEDBACK_E_FULL.json", "FEEDBACK_E_FULL_F.json"]:
        doc = json.loads((evidence / filename).read_text(encoding="utf-8"))
        shots = doc["shots"]
        feedback[filename] = {
            "rated_entries": len(shots),
            "picture_ratings": dict(Counter(s.get("pic", "missing") for s in shots.values())),
            "continuity_field_missing": sum("con" not in s for s in shots.values()),
        }
    anchor_groups = defaultdict(Counter)
    for line in (evidence / "filmE_anchor_vs_verdict.txt").read_text(encoding="utf-8").splitlines():
        if not (line.startswith("s") and len(line) > 1 and line[1].isdigit()) or "|" not in line:
            continue
        _, group, verdict = [part.strip() for part in line.split("|")]
        anchor_groups[group][verdict] += 1

    return {
        "scope": "attached storage helper and supplied evidence only; no app integration, provider calls, production writes, or R2 source audit",
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "source_bytes": len(raw),
        "storage_probes": cases,
        "feedback_counts": feedback,
        "total_rated_entries": sum(f["rated_entries"] for f in feedback.values()),
        "anchor_verdict_counts": {k: dict(v) for k, v in anchor_groups.items()},
        "all_probe_assertions_passed": True,
    }


if __name__ == "__main__":
    if len(sys.argv) not in (2, 3):
        raise SystemExit(__doc__)
    result = audit(Path(sys.argv[1]))
    serialized = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(serialized, encoding="utf-8")
    print(serialized)
